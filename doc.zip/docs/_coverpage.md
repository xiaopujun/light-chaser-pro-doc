# LIGHT CHASER PRO <small><code>v2026.2.0</code></small>

<p style="font-size: 18px">高性能、易扩展、功能强大的企业级数据可视化工具</p>
<p>蓝图交互，操作简单、自定义组件</p>

[开始](/introduce)
[开源仓库](https://github.com/xiaopujun/lcp-desktop)
[官网](http://www.lcpdesigner.cn)
[马上体验](http://www.lcdesigner.cn/home/server)
